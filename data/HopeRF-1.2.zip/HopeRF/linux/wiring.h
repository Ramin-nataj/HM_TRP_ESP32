// wiring.h
// fake Arduino wiring.h for compiling on Linux

typedef unsigned char uint8_t;

typedef unsigned int uint16_t;
