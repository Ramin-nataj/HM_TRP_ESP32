// This is only used while testing on Linux
// Define stuff we neeed when we are not running on arduino

#define ISR void ISR_func
#define SIGNAL void ISR_func
#define __vector_11
